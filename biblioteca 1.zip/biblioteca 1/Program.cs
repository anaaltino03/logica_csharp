﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace biblioteca_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Mapear os requisitos do sistema e implementar no console em C# a estrutura de classes com suas respectivas propriedades , simulando a instanciação de objetos na memória.
            int opcao = 0;
            while (opcao != 0)
            {
                Console.Clear(); //limpa a tela
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(@"
░██████╗██╗░██████╗████████╗███████╗███╗░░░███╗░█████╗░  ██████╗░███████╗
██╔════╝██║██╔════╝╚══██╔══╝██╔════╝████╗░████║██╔══██╗  ██╔══██╗██╔════╝
╚█████╗░██║╚█████╗░░░░██║░░░█████╗░░██╔████╔██║███████║  ██║░░██║█████╗░░
░╚═══██╗██║░╚═══██╗░░░██║░░░██╔══╝░░██║╚██╔╝██║██╔══██║  ██║░░██║██╔══╝░░
██████╔╝██║██████╔╝░░░██║░░░███████╗██║░╚═╝░██║██║░░██║  ██████╔╝███████╗
╚═════╝░╚═╝╚═════╝░░░░╚═╝░░░╚══════╝╚═╝░░░░░╚═╝╚═╝░░╚═╝  ╚═════╝░╚══════╝

░██████╗░███████╗░██████╗████████╗░█████╗░░█████╗░  ██████╗░███████╗
██╔════╝░██╔════╝██╔════╝╚══██╔══╝██╔══██╗██╔══██╗  ██╔══██╗██╔════╝
██║░░██╗░█████╗░░╚█████╗░░░░██║░░░███████║██║░░██║  ██║░░██║█████╗░░
██║░░╚██╗██╔══╝░░░╚═══██╗░░░██║░░░██╔══██║██║░░██║  ██║░░██║██╔══╝░░
╚██████╔╝███████╗██████╔╝░░░██║░░░██║░░██║╚█████╔╝  ██████╔╝███████╗
░╚═════╝░╚══════╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░  ╚═════╝░╚══════╝

██████╗░██╗██████╗░██╗░░░░░██╗░█████╗░████████╗███████╗░█████╗░░█████╗░
██╔══██╗██║██╔══██╗██║░░░░░██║██╔══██╗╚══██╔══╝██╔════╝██╔══██╗██╔══██╗
██████╦╝██║██████╦╝██║░░░░░██║██║░░██║░░░██║░░░█████╗░░██║░░╚═╝███████║
██╔══██╗██║██╔══██╗██║░░░░░██║██║░░██║░░░██║░░░██╔══╝░░██║░░██╗██╔══██║
██████╦╝██║██████╦╝███████╗██║╚█████╔╝░░░██║░░░███████╗╚█████╔╝██║░░██║
╚═════╝░╚═╝╚═════╝░╚══════╝╚═╝░╚════╝░░░░╚═╝░░░╚══════╝░╚════╝░╚═╝░░╚═╝");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("1 - Cadastrar Livro");
                Console.WriteLine("2- Cadastrar Jogo");
                Console.WriteLine("3 - Cadastrar Cliente");
                Console.WriteLine("4 - astrar Fornecedor");
                Console.WriteLine("5 - Registrar Empréstimo");
                Console.WriteLine("0 - sair");
                Console.ResetColor();
                opcao = int.Parse(Console.ReadLine());
                switch (opcao)
                {
                    case 1:
                        Cadastro_Livro();
                        break;
                    case 2:
                        Cadastro_jogo();
                        break;
                    case 3:
                        Classe_cliente();
                        break;
                    case 4:
                        break;
                    case 5:
                        break;
                    case 0:
                        Console.Clear();
                        Console.WriteLine("Saindo do Programa");
                        break;
                }
            }
        }
        static void Cadastro_Livro()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
█▀▀ ▄▀█ █▀▄ ▄▀█ █▀ ▀█▀ █▀█ █▀█   █▀▄ █▀▀   █░░ █ █░█ █▀█ █▀█
█▄▄ █▀█ █▄▀ █▀█ ▄█ ░█░ █▀▄ █▄█   █▄▀ ██▄   █▄▄ █ ▀▄▀ █▀▄ █▄█");
            Console.ResetColor();

            string titulo;
            string autor;
            string obra;
            string idennacional;
            string categoria;

            int idenunico;
            int ano;
            int copias;

            Console.Write("Digite o ID do livro: ");
            idenunico = int.Parse(Console.ReadLine());

            Console.Write("Digite o título do livro: ");
            titulo = Console.ReadLine();

            Console.Write("Digite o autor: ");
            autor = Console.ReadLine();

            Console.Write("Digite o genero");
            obra = Console.ReadLine();

            Console.Write("Digite o ISBN: ");
            idennacional = Console.ReadLine();

            Console.Write("Digite a categoria: ");
            categoria = Console.ReadLine();

            Console.Write("Digite o ano de publicação: ");
            ano = int.Parse(Console.ReadLine());

            Console.Write("Digite a quantidade de cópias: ");
            copias = int.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Livro cadastrado com sucesso!");
            Console.ResetColor();

            Console.WriteLine("\nDados cadastrados:");
            Console.WriteLine("ID: " + idenunico);
            Console.WriteLine("Título: " + titulo);
            Console.WriteLine("Autor: " + autor);
            Console.WriteLine("Obra: " + obra);
            Console.WriteLine("ISBN: " + idennacional);
            Console.WriteLine("Categoria: " + categoria);
            Console.WriteLine("Ano: " + ano);
            Console.WriteLine("Cópias: " + copias);

            Console.WriteLine("\nPressione ENTER para voltar ao menu.");
            Console.ReadLine();
            Console.ResetColor();
        }
        static void Cadastro_jogo()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(@"
█▀▀ ▄▀█ █▀▄ ▄▀█ █▀ ▀█▀ █▀█ █▀█   █▀▄ █▀▀   ░░█ █▀█ █▀▀ █▀█
█▄▄ █▀█ █▄▀ █▀█ ▄█ ░█░ █▀▄ █▄█   █▄▀ ██▄   █▄█ █▄█ █▄█ █▄█");
            int id;
            int faixa;
            int numminjogadores;
            int nummaxjogador;
            int qtdexemplar;
            string nome;
            string categoria;
            Console.ResetColor();
            Console.WriteLine("Digite o identificador único: ");
            id = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o nome do jogo: ");
            nome = Console.ReadLine();

            Console.WriteLine("Digite a categoria do jogo: ");
            categoria = Console.ReadLine();
            Console.WriteLine("Digite a faixa etária: ");
            faixa = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o numero minimo de jogadores: ");
            numminjogadores = int.Parse(Console.ReadLine());
            Console.WriteLine("Quantidade maxima de jogadores: ");
            nummaxjogador = int.Parse(Console.ReadLine());
            Console.WriteLine("Total de caixas disponiveis: ");
            qtdexemplar = int.Parse(Console.ReadLine());

            Console.WriteLine("\n Cadastro realizado com sucesso!!!");
            Console.WriteLine("\n + nome");
            Console.WriteLine("\n + id");
            Console.WriteLine("\n + categoria");
            Console.WriteLine("\n + faixa");
            Console.WriteLine("\n + numinjogadores");
            Console.WriteLine("\n + nummaxjogador");
            Console.WriteLine("\n + qtdexemplar");
            Thread.Sleep(3000);
        }
        static void Classe_cliente()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(@"𝘾𝙡𝙖𝙨𝙨𝙚 𝙘𝙡𝙞𝙚𝙣𝙩𝙚");
            int id;
            string nome; string cpf; string telefone; string email;
            DateTime datanascimento;
            bool ativo;
            Console.Write("Digite o ID do cliente: ");
            id = int.Parse(Console.ReadLine());

            Console.Write("Digite o nome do cliente: ");
            nome = Console.ReadLine();

            Console.Write("Digite o CPF: ");
            cpf = Console.ReadLine();

            Console.Write("Digite o telefone: ");
            telefone = Console.ReadLine();

            Console.Write("Digite o e-mail: ");
            email = Console.ReadLine();

            Console.Write("Digite a data de nascimento (dd/MM/yyyy): ");
            datanascimento = DateTime.Parse(Console.ReadLine());

            Console.Write("O cliente está ativo? (true/false): ");
            ativo = bool.Parse(Console.ReadLine());

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nCliente cadastrado com sucesso!");
            Console.ResetColor();

            Console.WriteLine("\nDados cadastrados:");
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("CPF: " + cpf);
            Console.WriteLine("Telefone: " + telefone);
            Console.WriteLine("E-mail: " + email);
            Console.WriteLine("Data de nascimento: " + datanascimento.ToString("dd/MM/yyyy"));
            Console.WriteLine("Ativo: " + ativo);

            Console.WriteLine("\nPressione ENTER para voltar ao menu.");
            Console.ReadLine();
        }

    }
        }
    

