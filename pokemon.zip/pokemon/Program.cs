﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pokemon
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] nomepokemon = { "Pikachu ", "bulbasaur ", "charmander", "squirtle", "zubat", "meowth", "psyduck ", "Poliwag ", "machop ", "poliwhirl " };
            string[] tipopokemon = { "eletrico ", "grama/veneno ", "fogo ", "agua lutador ", "agua        " };
            string[] pesopokemon = {
                "6.0 kg",  // Pikachu
                "6.9 kg",  // bulbasaur
                "8.5 kg",  // charmander
                "9.0 kg",  // squirtle
                "7.5 kg",  // zubat
                "4.2 kg",  // meowth
                "19.6 kg",  // psyduck
                "12.4 kg",  // Poliwag
                "19.5 kg",  // machop
                "20.0 kg",  // poliwhirl
            };
            string[] tamanhopokemon = {
"0.4 m", // Pikachu
             "0.7 m",     // bulbasaur
              "0.6 m",   // charmander
               "0.5 m",   // squirtle
               "0.8 m",  // zubat
              "0.4 m",    // meowth
             "0.8 m",     // psyduck
           "0.6 m",        // Poliwag
               "0.8 m",  // machop
               "1.0 m",   // poliwhirl
            };
            int[] numeropokemon = {
              25, // Pikachu
              4,   // charmander
              7, // squirtle
              41,  // zubat
              52,  // meowth
              54,  // psyduck
             60,  // Poliwag
             56,   // machop
              61,  // poliwhirl
            };

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nListagem de pokemons");
            Console.ResetColor();
            for (int i = 0; i < numeropokemon.Length; i++) //Lenght -- soma o total de itens do vetor
            {
                Console.WriteLine("id:     " + numeropokemon[i]);
                Console.WriteLine("nome:    " + nomepokemon[i]);
                Console.WriteLine("tipo:     " + tipopokemon[i]);
                Console.WriteLine("altura:    " + tamanhopokemon[i]);
                Console.WriteLine("peso:     " + pesopokemon[i]);
                Console.WriteLine("===================================");













            }
        }
    }
}
