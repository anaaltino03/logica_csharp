﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atividade
{
    internal class Program
    {//"Implemente um sistema que armazene as quantidades de 5 tipos de frutas em 3 cestas e calcule o total de frutas de cada tipo."
        static void Main(string[] args)
        {
            int[,] frutas = new int[3, 5];
            string[] tipofruta = { "Uva", "morango", "banana", "manga", "limao" };
           for (int cesta = 0; cesta < tipofruta.Length; cesta++) 
            {
                Console.WriteLine("cesta" + (cesta + 1));
                for (int fruta = 0; fruta < 5; fruta++)
                {
                    Console.Write("Quantidade de " + tipofruta[fruta] + ": ");
                    frutas[cesta, fruta] = int.Parse(Console.ReadLine());
                }

                Console.WriteLine();
            }
            Console.WriteLine("TOTAL DE FRUTAS");

            for (int fruta = 0; fruta < 5; fruta++)
            {
                int total = 0;

                for (int cesta = 0; cesta < 3; cesta++)
                {
                    total += frutas[cesta, fruta];
                }

                Console.WriteLine(tipofruta[fruta] + ": " + total);
            }

            Console.ReadKey();





        }
    }
}
